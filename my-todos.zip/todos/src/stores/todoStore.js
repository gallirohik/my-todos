import { observable, computed, action, decorate } from "mobx";

class TodoStore {
  todos = [];
  addTodo(todo) {
    this.todos.push(todo);
  }
  get todosCount() {
    return this.todos.length;
  }

  updateTodo(id) {
    const updatedTodos = this.todos.map(todo => {
      if (todo.id === id) {
        todo.isCompleted = !todo.isCompleted;
      }
      return todo;
    });
    this.todos = updatedTodos;
  }
}
decorate(TodoStore, {
  todos: observable,
  todosCount: computed,
  addTodo: action,
  updateTodo: action
});
const store = new TodoStore();
export default store;
