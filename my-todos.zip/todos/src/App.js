import React, { Component } from "react";
import "./App.css";
import { inject, observer } from "mobx-react";
import Header from "./components/Header";
import MainContent from "./components/MainContent";
const App = inject("TodoStore")(
  observer(
    class App extends Component {
      render() {
        const { TodoStore } = this.props;
        return (
          <React.Fragment>
            <Header todosCount={TodoStore.todosCount} />
            <MainContent TodoStore={TodoStore} />
          </React.Fragment>
        );
      }
    }
  )
);

export default App;
