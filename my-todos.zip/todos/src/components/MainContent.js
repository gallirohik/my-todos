import React, { Component } from "react";
import { observer } from "mobx-react";
import TodoItem from "./TodoItem";
const MainContent = observer(
  class MainContent extends Component {
    constructor() {
      super();
      this.handleAddTodo = this.handleAddTodo.bind(this);
      this.handleChange = this.handleChange.bind(this);
    }
    handleChange(id) {
      this.props.TodoStore.updateTodo(id);
    }
    handleAddTodo(e) {
      e.preventDefault();
      const TodoStore = this.props.TodoStore;
      let todo = Object.assign(
        {},
        {
          id: TodoStore.todosCount + 1,
          text: this.todoItem.value,
          isCompleted: false
        }
      );
      TodoStore.addTodo(todo);
      this.todoItem.value = "";
    }

    render() {
      console.log("MainComponent");
      const TodoStore = this.props.TodoStore;
      const todosList = TodoStore.todos.map(todo => (
        <TodoItem key={todo.id} todo={todo} handleChange={this.handleChange} />
      ));
      let formStyles = {
        width: "47%",
        padding: "12px 20px",
        marginLeft: "23.2%",
        display: "inline-block",
        border: "1px solid #ccc",
        borderRadius: "4px",
        boxSizing: "border-box",
        fontSize: "22px"
      };
      let buttonStyles = {
        backgroundColor: "#4CAF50" /* Green */,
        border: "none",
        color: "white",
        padding: "12px 20px 10px",
        textAlign: "center",
        textDecoration: "none",
        display: "inline-block",
        fontSize: "16px"
      };
      return (
        <React.Fragment>
          <form onSubmit={e => this.handleAddTodo(e)}>
            <input
              style={formStyles}
              type="text"
              ref={input => (this.todoItem = input)}
            />
            <button style={buttonStyles}>Add Todo</button>
          </form>
          <div className="todo-list">{todosList}</div>
        </React.Fragment>
      );
    }
  }
);
export default MainContent;
