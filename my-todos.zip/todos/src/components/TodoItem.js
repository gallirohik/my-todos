import React, { Component } from "react";
import { observer } from "mobx-react";
const TodoItem = observer(
  class TodoItem extends Component {
    render() {
      console.log("TodoItem");
      const completedStyle = {
        fontStyle: "italic",
        color: "#cdcdcd",
        textDecoration: "line-through"
      };
      const styles = {
        fontSize: "22px"
      };
      let { id, text, isCompleted } = this.props.todo;
      console.log(`todoItem ${isCompleted} ${this.props.todo.isCompleted}`);
      return (
        <React.Fragment>
          <div className="todo-item" style={styles}>
            <input
              type="checkBox"
              onChange={() => {
                this.props.handleChange(id);
              }}
            />
            <p style={isCompleted ? completedStyle : null}>{text}</p>
          </div>
        </React.Fragment>
      );
    }
  }
);

export default TodoItem;
