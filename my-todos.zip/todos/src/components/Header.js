import React from "react";

function Header(props) {
  let Styles = {
    marginLeft: "23.2%"
  };
  return (
    <React.Fragment>
      <header className="navbar">
        <h1 style={Styles}>Your todos {props.todosCount}</h1>
      </header>
    </React.Fragment>
  );
}
export default Header;
